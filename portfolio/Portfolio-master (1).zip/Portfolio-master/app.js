
console.log(window.innerHeight);
let index = 0 // This variable kepps track of what section is on the screen
function handleSwipe(direction){
    const input = document.querySelector('input')
        switch (direction) {
            case 'up':
                if(index !== 3){
                    scrollToSection(++index)
                }else{
                    scrollToSection(0)
                    index = 0 ;
                }
                break;

            case 'down':
                if(index !== 0)
                scrollToSection(--index)
                break;

            case 'left':
                if(index !== 1)
                {openMenu(false)
                input.checked = false}
                break;

            case 'right':
                if (index !== 1)
                {openMenu(true)
                input.checked = true}
                break;
        
            default:
                break;
        }
}

//This function does the section 
// This does not behave as expected in ios
function scrollToSection(position, clicked){
    const navs = ['#Home', '#projects', '#skills', "#contactMe"]
    const el =  document.querySelector(navs[position])
    if (clicked) index = position
    setTimeout(() => {    
        if (position === 1 || position === 2) {
            animateProjects()
            toggleContacts('close')
        }else{
            toggleContacts('open')
        }

        if(position === 3){
            setTimeout(() => {
                moveContactsToCenter('open')
            }, 500);
        }
        else{
            moveContactsToCenter('close')
        }
        el.scrollIntoView(true)
    }, clicked?500:50);
}


//Handles all touch events on mobile
function touchEvents(){
    
    document.querySelectorAll('.container')
    .forEach(el => {
        el.addEventListener('touchstart', handleTouchStart, false)
        el.addEventListener('touchmove', handleTouchMove, false)
        el.addEventListener('touchend', handleTouchEnd, false)
    })
    let x = null;
    let y = null;
    let startTime;
    let direction = null
    const input = document.querySelector('input')

    

    x = null;
    y = null;
    
    function getTouches(evt){
        return evt.touches[0]
    }

    function handleTouchStart(evt){
        startTime = Date.now()
        const firstTouch = getTouches(evt)
        x = firstTouch.clientX
        y = firstTouch.clientY
    }
    function handleTouchMove(evt){
        let xUp = getTouches(evt).clientX
        let yUp = getTouches(evt).clientY

        let xDiff = x - xUp
        let yDiff = y - yUp

        if (Math.abs(xDiff) > Math.abs(yDiff)){
            if(xDiff > 0){
                direction = 'left'
                

            } else{
                direction = 'right'

            }
        }else{
            if(yDiff > 0){
                direction = 'up'
            }else{
                direction = 'down'
                
            }
        }
    }
    
    
    function handleTouchEnd(){
        const endTime = Date.now()
        const timeDiff = endTime - startTime
        if(timeDiff > 150 )                     //this is to prevent short touches from causing the screen to scroll
        {
            openMenu(false)
            console.log("you have scrolled");
            handleSwipe(direction)
        }
    }
}


//handles keyboard and wheel events
function wheelEvent(){
    document.querySelector('body').addEventListener('keydown', (e)=>{
        switch (e.key) {
            case 'ArrowDown':
                handleSwipe('up')
                break;

            case 'ArrowUp':
                handleSwipe('down')
                break;
        
            default:
                break;
        }
    })
    

    function handleKeydown(e){
        console.log(e);
    }
}

//opens menu when the menu icon is clicked
function openMenu (open){
    const input = document.querySelector('input')
          input.checked = open
    const main =  document.querySelectorAll('.container')
                    .forEach(el => {
                        el.style.marginTop = open?'5vh':0
                        el.style.marginLeft = open?(window.innerWidth > 768 ?'30vw':'40vw'):0
                        el.style.borderTopLeftRadius= open?'10vh':0
                    })
    const menuIcon =  document.querySelector('.switch')
    menuIcon.style.marginTop = open?'5vh':0
    menuIcon.style.marginLeft = open?(window.innerWidth > 768 ?'25vw':'40vw'):0
}

//animates the fading texts and controls the images by replacing nodes
function animateSkills() {
    const skillsElement =  document.querySelector('#skills ul').children   
    let position = 0     //Keeps track of the position the element being animated  
    const imgArray = ["./images/html.png", "./images/css.png", "./images/scss.png", "./images/js.png", "./images/gas.png", "./images/react.png", "./images/ReactN.png"]
    const imgElement = imgArray.map(img => {
                            const pic = new Image()
                            pic.src = img
                            return pic // creates an array with image nodes
                        })




    /**
     * This loops through the Html collection,
     * adds an event listener to listen for when an animation ends
     * and finally pushes each element into the 'skillsArray
     */
    for (let index = 0; index < skillsElement.length; index++) {
        const element = skillsElement[index];
        element.addEventListener('animationend', ()=>{
            skillsElement[position].classList.remove('fadeText')     //removes animation class after animation ends
            loopAnimation(++position) //starts animation for the next element in the array
        })
    }

    /**
     * This function adds the "fadeText" class to an element in the 'skillsArray
     * In other to achieve a loop, it checks the position and if it is greater than the index of the 'skillArray', it resets the 'position' variable
     */
    const loopAnimation = (index) =>{   
        if(index <=  (skillsElement.length-1)){
            skillsElement[index].classList.add('fadeText') //add a class that fades in the text
            document.querySelector('#skills > div').firstElementChild.replaceWith(imgElement[index])  //replaces the image node
        }
        else{
            position = 0
            skillsElement[0].classList.add('fadeText')
            document.querySelector('#skills > div').firstElementChild.replaceWith(imgElement[0])  //replaces the image node

        }
    }

    // Starts the fading animation
    loopAnimation(position)


    
    
}

//handles the animation of the circles in the skills section
function animateCirle(){
    const imageDiv = document.querySelector('#skills div')
    let index = -1;
    let imageIndex = -1
    const animation ={
        0: ['width', '0px'],
        1: ['width', '200px'],
        2: ['transform', 'scale(0)'],
        3: ['transform', 'scale(1)'],
        4: ['height', '0px'],
        5: ['height', '200px'],
    }
    const  publicFunction = () => {
                if(index >= 5){
                    index = -1
                }
                let j = ++index
                imageDiv.style[animation[j][0]] = animation[j][1]
                
            }
    
    
    imageDiv.addEventListener('transitionend', ()=>{
        publicFunction()
    })
   
    publicFunction()
}

// handles the project section
const animateProjects = () => {
    const projects = []  //an array to store all project nodes
    let index =  -1
    document.querySelectorAll('.projects').forEach((project, index, arr) => {
       
        project.style.transitionDuration = '0.8s'
        
        
        projects.push(project) //populate the array with all project nodes

        project.addEventListener('transitionend', () => {
            moveInProjects()  //moves in the next project after the style of the previous one has finished transitioning
        })


    })
    
    const moveInProjects = () => {
        while(index < projects.length-1){
            projects[++index].style.marginLeft = '35px'  //this change in style caused the projects to slide in from the right
        }
    }

    moveInProjects() //starts the animation

    const imgSource = ['./images/typing.gif', './images/Tckr.gif', './images/portfolio.gif',  './images/Animation.gif', './images/Upwork.gif',  './images/twitter.gif']
    document.querySelectorAll('.projects img').forEach((img, index) => {
        img.src = imgSource[index]  //To make the page load faster the gifs are added when the projects section is in view
    })

}

//fades in and out the about section
function toggleAbout(state){
    document.querySelector('#aboutMe').classList.toggle('animateAbout')
 
}

function toggleContacts(state){
    if(state === "close"){
        document.querySelectorAll('.contacts').forEach(contact => {
            contact.classList.add("closeContacts")
        })
    } else if (state === "open") {
        document.querySelectorAll('.contacts').forEach(contact => {
            contact.classList.remove("closeContacts")
        })
    }
    
}
function moveContactsToCenter(state){
    if(state === 'open'){
        document.querySelector("#allContacts").classList.add('moveContactsToCenter')
    }else{
        document.querySelector("#allContacts").classList.remove('moveContactsToCenter')
    }
}
window.addEventListener('load', ()=>{
    //Add an event listener to the checkbox which fires the openMenu function when clicked

    console.log('go');
    const input = document.querySelector('input')
    input.addEventListener('click', ()=>{
        if(input.checked){
            openMenu(true);
        }else{
            openMenu(false);
        }
    })

    //Loop through all and  add the class with the animation while simultenously increasing the delay
  

    setTimeout(() => {
        animateCirle()
    }, 1000);

    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', (e)=> {
            e.preventDefault()
            input.checked = false
            openMenu(false)
        })
    })

    touchEvents()
    wheelEvent()
    animateSkills()




   
    
})

//This animated in the name
 document.querySelectorAll('.text').forEach((e, i)=>{
    e.classList.add('textAnimation')
    e.addEventListener('animationend', ()=>{
        e.style.transform = 'rotate3d(0, 0, 0, 90deg)'

    })
    
    e.style.animationDelay = `${1 + i*0.08}s`
})







